* In the `Input` category, a few tables for converting from enumerants
  to variants would still be useful.

* myocamlbuild.ml static linking 
    flag ["link"; "static"; "ocaml"; tag] 
    (S [A "-cclib"; A "/usr/local/lib/libSDL2.a"])





